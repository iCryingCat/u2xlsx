--[[ E:/code/c#/xlsx-exporter/bin/Debug/net7.0/publish/xlsx/C1-测试.xlsx ]]--
-- 测试lua枚举
local XLSX_GLOBAL_LANGUAGE = {
-- 中文
ZN = 1,
-- 英语
EN = 3,
}
return XLSX_GLOBAL_LANGUAGE