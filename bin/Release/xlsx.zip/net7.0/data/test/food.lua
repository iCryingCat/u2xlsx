--[[ E:/code/c#/xlsx-exporter/bin/Release/net7.0/assets/测试@test.xlsx ]]--
-- 测试lua枚举
local XLSX_TEST_FOOD = {
-- 中文
ZN = 1,
-- 英语
EN = 3,
}
return XLSX_TEST_FOOD