--[[ E:/code/c#/xlsx-exporter/bin/Release/net7.0/assets/测试@test.xlsx ]]--
-- 测试表
local XLSX_TEST_USER = {
-- 昵称
name = '白泽',
-- 年龄
age = 20,
}
return XLSX_TEST_USER