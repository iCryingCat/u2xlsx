namespace XLSX.GLOBAL
{
    // 用户表
    public class USER
    {
        // 昵称
        public string name { get; set; }
        // 年龄
        public float age { get; set; }

    }

}
