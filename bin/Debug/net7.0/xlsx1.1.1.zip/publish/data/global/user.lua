--[[ E:/code/c#/xlsx-exporter/bin/Debug/net7.0/publish/xlsx/C1-测试.xlsx ]]--
-- 测试表
local XLSX_GLOBAL_USER = {
-- 昵称
name = '白泽',
-- 年龄
age = 20,
}
return XLSX_GLOBAL_USER