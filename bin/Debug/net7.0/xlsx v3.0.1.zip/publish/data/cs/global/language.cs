namespace XLSX.GLOBAL
{
    // 语言表
    public enum LANGUAGE
    {
        // 中文
        ZN = 1,
        // 英语
        EN = 3,

    }

}
